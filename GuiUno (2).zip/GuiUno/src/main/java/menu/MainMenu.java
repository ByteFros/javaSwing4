package menu;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import autentificacion.AuthGUI;
import idiomas.LanguageManager;
import puntuaciones.HighScoresGUI;
import juego.GameGui;

public class MainMenu extends JFrame {
    private JButton playButton, createUserButton, viewScoresButton, languageButton, loginButton;
    private boolean isLoggedIn = false;

    public MainMenu() {
        setTitle(getMessage("mainMenuTitle"));
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 1));

        playButton = new JButton(getMessage("playButton"));
        createUserButton = new JButton(getMessage("createUserButton"));
        viewScoresButton = new JButton(getMessage("viewScoresButton"));
        languageButton = new JButton(getMessage("languageButton"));
        loginButton = new JButton(getMessage("loginButton"));

        panel.add(playButton);
        panel.add(createUserButton);
        panel.add(viewScoresButton);
        panel.add(languageButton);
        panel.add(loginButton);

        add(panel);

        playButton.setEnabled(false);

        playButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isLoggedIn) {
                    new GameGui().setVisible(true);
                } else {
                    showMessageDialog(MainMenu.this, "loginRequired", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        createUserButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AuthGUI(MainMenu.this).setVisible(true);
            }
        });

        viewScoresButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new HighScoresGUI().setVisible(true);
            }
        });

        languageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] options = { "Español", "Català", "English" };
                String selectedLanguage = (String) JOptionPane.showInputDialog(
                        MainMenu.this,
                        getMessage("chooseLanguage"),
                        "Idioma",
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        options,
                        options[0]);

                if (selectedLanguage != null) {
                    LanguageManager.getInstance().changeLanguage(selectedLanguage);
                    dispose();  // Cierra la ventana actual
                    new MainMenu().setVisible(true);  // Abre una nueva instancia de la interfaz gráfica
                }
            }
        });

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AuthGUI(MainMenu.this).setVisible(true);
            }
        });
    }

    // Método para obtener mensajes dinámicamente
    private String getMessage(String key) {
        return LanguageManager.getInstance().getString(key);
    }

    // Método para mostrar mensajes dinámicos
    private void showMessageDialog(Component parentComponent, String key, String title, int messageType) {
        String message = getMessage(key);
        JOptionPane.showMessageDialog(parentComponent, message, title, messageType);
    }

    public void updatePlayButtonStatus(boolean isLoggedIn) {
        this.isLoggedIn = isLoggedIn;
        playButton.setEnabled(isLoggedIn);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MainMenu().setVisible(true);
            }
        });
    }
}