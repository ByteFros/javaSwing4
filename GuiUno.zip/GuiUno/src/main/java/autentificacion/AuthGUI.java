package autentificacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import menu.MainMenu;
import idiomas.LanguageManager;

public class AuthGUI extends JFrame {
    private JTextField userField;
    private JPasswordField passField;
    private JButton registerButton, loginButton;
    private MainMenu mainMenu;

    public AuthGUI(MainMenu mainMenu) {
        this.mainMenu = mainMenu;

        setTitle(getMessage("registerTitle"));
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        userField = new JTextField(20);
        passField = new JPasswordField(20);
        registerButton = new JButton(getMessage("registerButton"));
        loginButton = new JButton(getMessage("loginButton"));

        add(new JLabel(getMessage("usernameLabel")));
        add(userField);
        add(new JLabel(getMessage("passwordLabel")));
        add(passField);
        add(registerButton);
        add(loginButton);

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = userField.getText().trim();
                String password = new String(passField.getPassword()).trim();

                if (username.isEmpty() || password.isEmpty()) {
                    showMessageDialog(AuthGUI.this, "emptyFieldsError", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (usuarioExiste(username)) {
                    showMessageDialog(AuthGUI.this, "userExistsError", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                guardarUsuarioEnCSV(username, password);
                String message = getMessage("userRegistered") + " " + username;
                showMessageDialog(AuthGUI.this, message, getMessage("successTitle"), JOptionPane.INFORMATION_MESSAGE);
                dispose();
            }
        });

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = userField.getText().trim();
                String password = new String(passField.getPassword()).trim();

                if (verificarCredenciales(username, password)) {
                    String message = getMessage("loginSuccess") + " " + username;
                    showMessageDialog(AuthGUI.this, message, getMessage("successTitle"), JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                    mainMenu.updatePlayButtonStatus(true);
                } else {
                    showMessageDialog(AuthGUI.this, "loginError", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        setVisible(true);
    }

    private static final String filePath = "usuarios.csv";

    // Método para guardar el usuario en el archivo CSV
    public static void guardarUsuarioEnCSV(String username, String password) {
        try (FileWriter writer = new FileWriter(filePath, true)) {
            writer.append(username).append(",").append(password).append("\n");
        } catch (IOException ex) {
            showMessageDialog(null, "errorSavingUser", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Verificar si el usuario ya existe en el archivo CSV
    public static boolean usuarioExiste(String username) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] credentials = line.split(",");
                if (credentials.length == 2 && credentials[0].equals(username)) {
                    return true;  // El usuario ya existe
                }
            }
        } catch (IOException ex) {
            showMessageDialog(null, "errorReadingFile", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;  // El usuario no existe
    }

    // Verificar las credenciales para iniciar sesión
    public static boolean verificarCredenciales(String username, String password) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] credentials = line.split(",");
                if (credentials.length == 2 && credentials[0].equals(username) && credentials[1].equals(password)) {
                    return true;  // Las credenciales son correctas
                }
            }
        } catch (IOException ex) {
            showMessageDialog(null, "errorReadingFile", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;  // Las credenciales son incorrectas
    }

    // Método para obtener mensajes dinámicamente
    private static String getMessage(String key) {
        try {
            return LanguageManager.getInstance().getString(key);
        } catch (java.util.MissingResourceException e) {
            return "[" + key + "]"; // Devuelve la clave entre corchetes si no se encuentra
        }
    }

    // Método para mostrar mensajes dinámicos
    private static void showMessageDialog(Component parentComponent, String key, String title, int messageType) {
        String message = getMessage(key);
        JOptionPane.showMessageDialog(parentComponent, message, title, messageType);
    }
}